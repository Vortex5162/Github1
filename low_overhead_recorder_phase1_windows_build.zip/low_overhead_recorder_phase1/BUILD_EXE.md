# Build a Windows EXE automatically

This repository includes a GitHub Actions workflow that builds `recorder_probe.exe` on a Windows runner. It does not mean the executable is already included in this ZIP.

1. Sign in to GitHub and create a **private** repository (for example, `low-overhead-recorder`).
2. Extract this ZIP on your PC.
3. Upload the extracted project files to that repository, preserving `.github/workflows/build-windows.yml` and the folder structure. Alternatively, use GitHub Desktop to publish the folder.
4. Open the repository's **Actions** tab and select **Build Windows EXE**. If the workflow has not run automatically after pushing to `main`, click **Run workflow**.
5. Open the completed run and download the `recorder-probe-windows-x64` artifact. Extract it to get `recorder_probe.exe`.

The resulting program is only the Phase 1 DXGI capture/telemetry probe. It is not yet a full game recorder: it does not encode video, capture audio, or provide instant replay. Run it on Windows 10/11. Because the program is not code-signed, Windows SmartScreen may show a warning; only run it after reviewing the source code you uploaded.

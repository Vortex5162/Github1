# Phase 1 benchmark protocol

## Purpose

Establish a repeatable desktop-capture baseline before integrating NVENC. This prototype's acquisition rate is not the same thing as the game's rendered FPS; collect game frame-time traces separately.

## Test controls

- Use the same game scene and route for every run.
- Keep display resolution, refresh rate, graphics settings, laptop power mode, and background applications unchanged.
- Connect AC power and let the laptop reach a stable thermal state before each set.
- Run at least three repetitions per condition, ideally 120 seconds each.
- Do not compare results collected under different game or driver updates.

## Conditions

1. Game running, no recorder: baseline.
2. Game running with a reference recorder at 1080p120 H.264 NVENC.
3. Game running with Phase 1 probe capturing the same display.
4. Later milestone: custom recorder with NVENC enabled and the same quality target.
5. Later milestone: custom recorder with instant replay enabled and a replay export during continued recording.

## Collect

- PresentMon trace for each run.
- `telemetry.csv` from the probe.
- GPU/CPU utilization, VRAM and RAM use, clocks, temperatures, and power mode.
- Recorder counters for frames acquired, dropped-before-encode, encoder errors, queue depth, and disk-write latency as those features are implemented.

## Initial comparison goals

These are acceptance targets, not expected or guaranteed results:

- Average FPS loss versus no recording: <= 3%.
- 1% low FPS degradation: <= 5%.
- P99 game frame-time degradation: <= 5%.
- Dropped recording frames in a sustained run: < 0.1%.
- No unbounded queue growth or corrupt output.

If the target is missed, inspect frame-time traces and per-stage counters before changing settings. Test one GPU-bound and one CPU-bound game because recorder overhead depends on the workload.

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <wrl/client.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <csignal>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iterator>
#include <iostream>
#include <memory>
#include <numeric>
#include <sstream>
#include <string>
#include <stdexcept>
#include <vector>

using Microsoft::WRL::ComPtr;

namespace {
std::atomic_bool g_stop{false};

BOOL WINAPI ConsoleHandler(DWORD type) {
    if (type == CTRL_C_EVENT || type == CTRL_BREAK_EVENT || type == CTRL_CLOSE_EVENT) {
        g_stop.store(true, std::memory_order_relaxed);
        return TRUE;
    }
    return FALSE;
}

void CheckHR(HRESULT hr, const char* operation) {
    if (FAILED(hr)) {
        std::ostringstream message;
        message << operation << " failed (HRESULT 0x" << std::hex << std::uppercase
                << static_cast<unsigned long>(hr) << ")";
        throw std::runtime_error(message.str());
    }
}

struct FrameSample {
    std::uint64_t frame_index{};
    std::int64_t qpc_ticks{};
    double elapsed_ms{};
    double interval_ms{};
    UINT width{};
    UINT height{};
};

struct CaptureTarget {
    ComPtr<IDXGIAdapter1> adapter;
    ComPtr<IDXGIOutput> output;
    DXGI_OUTPUT_DESC description{};
    std::wstring adapter_name;
};

CaptureTarget FindAttachedOutput() {
    ComPtr<IDXGIFactory1> factory;
    CheckHR(CreateDXGIFactory1(IID_PPV_ARGS(&factory)), "CreateDXGIFactory1");

    for (UINT adapter_index = 0;; ++adapter_index) {
        ComPtr<IDXGIAdapter1> adapter;
        const HRESULT adapter_hr = factory->EnumAdapters1(adapter_index, &adapter);
        if (adapter_hr == DXGI_ERROR_NOT_FOUND) break;
        CheckHR(adapter_hr, "EnumAdapters1");

        DXGI_ADAPTER_DESC1 adapter_desc{};
        CheckHR(adapter->GetDesc1(&adapter_desc), "IDXGIAdapter1::GetDesc1");

        for (UINT output_index = 0;; ++output_index) {
            ComPtr<IDXGIOutput> output;
            const HRESULT output_hr = adapter->EnumOutputs(output_index, &output);
            if (output_hr == DXGI_ERROR_NOT_FOUND) break;
            CheckHR(output_hr, "EnumOutputs");

            DXGI_OUTPUT_DESC output_desc{};
            CheckHR(output->GetDesc(&output_desc), "IDXGIOutput::GetDesc");
            if (output_desc.AttachedToDesktop) {
                CaptureTarget target;
                target.adapter = adapter;
                target.output = output;
                target.description = output_desc;
                target.adapter_name = adapter_desc.Description;
                return target;
            }
        }
    }
    throw std::runtime_error("No display output attached to the desktop was found.");
}

double Percentile(std::vector<double> values, double percentile) {
    if (values.empty()) return 0.0;
    std::sort(values.begin(), values.end());
    const auto index = static_cast<std::size_t>(std::ceil(percentile * static_cast<double>(values.size() - 1)));
    return values[std::min(index, values.size() - 1)];
}

void WriteCsv(const std::vector<FrameSample>& samples, const std::string& path) {
    std::ofstream file(path, std::ios::binary);
    if (!file) throw std::runtime_error("Could not create CSV telemetry file: " + path);
    file << "frame_index,qpc_ticks,elapsed_ms,interval_ms,width,height\n";
    file << std::fixed << std::setprecision(4);
    for (const auto& s : samples) {
        file << s.frame_index << ',' << s.qpc_ticks << ',' << s.elapsed_ms << ','
             << s.interval_ms << ',' << s.width << ',' << s.height << '\n';
    }
}

int Run() {
    SetConsoleCtrlHandler(ConsoleHandler, TRUE);
    std::cout << "Low-overhead recorder — Phase 1 capture/telemetry probe\n"
              << "Press Ctrl+C to stop and write telemetry.csv.\n\n";

    CaptureTarget target = FindAttachedOutput();
    std::wcout << L"Adapter: " << target.adapter_name << L"\n"
               << L"Output: " << target.description.DeviceName << L"\n";

    const LONG width_long = target.description.DesktopCoordinates.right - target.description.DesktopCoordinates.left;
    const LONG height_long = target.description.DesktopCoordinates.bottom - target.description.DesktopCoordinates.top;
    if (width_long <= 0 || height_long <= 0) throw std::runtime_error("The selected output has invalid dimensions.");

    ComPtr<ID3D11Device> device;
    ComPtr<ID3D11DeviceContext> context;
    D3D_FEATURE_LEVEL obtained_level{};
    const D3D_FEATURE_LEVEL levels[] = {D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0};
    HRESULT device_hr = D3D11CreateDevice(
        target.adapter.Get(), D3D_DRIVER_TYPE_UNKNOWN, nullptr,
        D3D11_CREATE_DEVICE_BGRA_SUPPORT, levels, static_cast<UINT>(std::size(levels)),
        D3D11_SDK_VERSION, &device, &obtained_level, &context);
    if (device_hr == E_INVALIDARG) {
        const D3D_FEATURE_LEVEL fallback_levels[] = {D3D_FEATURE_LEVEL_11_0};
        device_hr = D3D11CreateDevice(target.adapter.Get(), D3D_DRIVER_TYPE_UNKNOWN, nullptr,
            D3D11_CREATE_DEVICE_BGRA_SUPPORT, fallback_levels, 1, D3D11_SDK_VERSION,
            &device, &obtained_level, &context);
    }
    CheckHR(device_hr, "D3D11CreateDevice");

    ComPtr<IDXGIOutput1> output1;
    CheckHR(target.output.As(&output1), "Query IDXGIOutput1");
    ComPtr<IDXGIOutputDuplication> duplication;
    CheckHR(output1->DuplicateOutput(device.Get(), &duplication), "IDXGIOutput1::DuplicateOutput");

    LARGE_INTEGER qpc_frequency{};
    LARGE_INTEGER qpc_start{};
    CheckHR(QueryPerformanceFrequency(&qpc_frequency) ? S_OK : E_FAIL, "QueryPerformanceFrequency");
    CheckHR(QueryPerformanceCounter(&qpc_start) ? S_OK : E_FAIL, "QueryPerformanceCounter");

    std::vector<FrameSample> samples;
    samples.reserve(120 * 60 * 10);
    std::vector<double> intervals;
    intervals.reserve(120 * 60 * 10);
    std::uint64_t timeouts = 0;
    std::uint64_t access_lost = 0;
    std::uint64_t other_errors = 0;
    std::int64_t last_frame_qpc = 0;
    auto last_report = std::chrono::steady_clock::now();
    std::size_t last_report_frames = 0;
    const UINT width = static_cast<UINT>(width_long);
    const UINT height = static_cast<UINT>(height_long);

    std::cout << "Capture started: " << width << 'x' << height
              << " (desktop output; this phase does not encode video).\n";

    while (!g_stop.load(std::memory_order_relaxed)) {
        DXGI_OUTDUPL_FRAME_INFO frame_info{};
        ComPtr<IDXGIResource> desktop_resource;
        const HRESULT acquire_hr = duplication->AcquireNextFrame(250, &frame_info, &desktop_resource);

        if (acquire_hr == DXGI_ERROR_WAIT_TIMEOUT) {
            ++timeouts;
        } else if (acquire_hr == DXGI_ERROR_ACCESS_LOST) {
            ++access_lost;
            std::cerr << "Desktop duplication access lost; stopping this run. Restart the probe after a display/mode change.\n";
            break;
        } else if (FAILED(acquire_hr)) {
            ++other_errors;
            std::cerr << "AcquireNextFrame failed with HRESULT 0x" << std::hex << std::uppercase
                      << static_cast<unsigned long>(acquire_hr) << std::dec << '\n';
            break;
        } else {
            LARGE_INTEGER now{};
            QueryPerformanceCounter(&now);
            const auto elapsed_ticks = now.QuadPart - qpc_start.QuadPart;
            const double elapsed_ms = 1000.0 * static_cast<double>(elapsed_ticks) / static_cast<double>(qpc_frequency.QuadPart);
            const double interval_ms = last_frame_qpc == 0 ? 0.0 :
                1000.0 * static_cast<double>(now.QuadPart - last_frame_qpc) / static_cast<double>(qpc_frequency.QuadPart);
            last_frame_qpc = now.QuadPart;

            // Validate that DXGI supplied a texture. We deliberately do not read pixels back to the CPU.
            ComPtr<ID3D11Texture2D> frame_texture;
            const HRESULT texture_hr = desktop_resource.As(&frame_texture);
            if (SUCCEEDED(texture_hr)) {
                D3D11_TEXTURE2D_DESC texture_desc{};
                frame_texture->GetDesc(&texture_desc);
                FrameSample sample;
                sample.frame_index = samples.size() + 1;
                sample.qpc_ticks = now.QuadPart;
                sample.elapsed_ms = elapsed_ms;
                sample.interval_ms = interval_ms;
                sample.width = texture_desc.Width;
                sample.height = texture_desc.Height;
                samples.push_back(sample);
                if (interval_ms > 0.0) intervals.push_back(interval_ms);
            } else {
                ++other_errors;
            }
            duplication->ReleaseFrame();
        }

        const auto now_steady = std::chrono::steady_clock::now();
        if (now_steady - last_report >= std::chrono::seconds(1)) {
            const double elapsed_seconds = std::chrono::duration<double>(now_steady - last_report).count();
            const std::size_t n = samples.size();
            const double recent_fps = elapsed_seconds > 0.0 ?
                static_cast<double>(n - last_report_frames) / elapsed_seconds : 0.0;
            std::cout << "Frames acquired: " << n << " | recent acquisition rate: "
                      << std::fixed << std::setprecision(1) << recent_fps << " fps | timeouts: " << timeouts
                      << " | access lost: " << access_lost << " | errors: " << other_errors << "\r" << std::flush;
            last_report = now_steady;
            last_report_frames = n;
        }
    }

    const double total_seconds = samples.empty() ? 0.0 : samples.back().elapsed_ms / 1000.0;
    const double average_fps = total_seconds > 0.0 ? static_cast<double>(samples.size()) / total_seconds : 0.0;
    const double mean_interval = intervals.empty() ? 0.0 : std::accumulate(intervals.begin(), intervals.end(), 0.0) / static_cast<double>(intervals.size());
    const double p99_interval = Percentile(intervals, 0.99);

    std::cout << "\n\nRun summary\n"
              << "Frames acquired: " << samples.size() << '\n'
              << "Elapsed seconds: " << std::fixed << std::setprecision(2) << total_seconds << '\n'
              << "Average acquisition rate: " << std::setprecision(2) << average_fps << " frames/s (not a guaranteed game FPS measurement)\n"
              << "Mean acquisition interval: " << mean_interval << " ms\n"
              << "P99 acquisition interval: " << p99_interval << " ms\n"
              << "Acquire timeouts: " << timeouts << '\n'
              << "Access-lost events: " << access_lost << '\n'
              << "Other errors: " << other_errors << '\n';

    WriteCsv(samples, "telemetry.csv");
    std::cout << "Telemetry saved to telemetry.csv in the current working directory.\n";
    std::cout << "Note: this Phase 1 probe captures desktop frames only; NVENC, audio, replay, and game auto-detection are not implemented yet.\n";
    return 0;
}
} // namespace

int main() {
    try {
        return Run();
    } catch (const std::exception& ex) {
        std::cerr << "Fatal error: " << ex.what() << '\n';
        return 1;
    }
}

# Low-Overhead Recorder — Phase 1

A native Windows capture-and-telemetry prototype for the planned 1080p120 NVENC game recorder.

## What this milestone does

- Enumerates DXGI adapters and chooses the first output attached to the desktop.
- Creates a Direct3D 11 device on that output's adapter.
- Captures desktop frames using DXGI Desktop Duplication.
- Measures frame acquisition intervals and records per-frame telemetry.
- Writes `telemetry.csv` when you stop the program with Ctrl+C.
- Avoids CPU readback of captured pixels.

## What it does not do yet

This is deliberately a Phase 1 probe, not the finished recorder. It does **not** encode video, record audio, implement instant replay, automatically identify individual game windows, or guarantee 120 captured frames per second. Desktop Duplication reports desktop updates, which are not necessarily identical to the game's presented-frame stream. It also does not yet implement capture fallback/recovery after a display mode change.

## Requirements

- Windows 10 or Windows 11
- Visual Studio 2022 with the **Desktop development with C++** workload
- Windows 10/11 SDK
- CMake 3.24 or newer
- A desktop-attached DXGI output that supports Desktop Duplication

## Build (Visual Studio Developer PowerShell)

From this folder:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

Run the probe from a writable working directory so it can create `telemetry.csv`:

```powershell
.\build\Release\recorder_probe.exe
```

Press Ctrl+C to stop. The process prints a summary and writes `telemetry.csv` in its current working directory.

## Reading the CSV

- `frame_index`: sequentially acquired frame number
- `qpc_ticks`: QueryPerformanceCounter timestamp at acquisition
- `elapsed_ms`: milliseconds since the start of the run
- `interval_ms`: interval between consecutive successful acquisitions; first frame is zero
- `width`, `height`: dimensions of the captured texture

The reported acquisition rate is not a substitute for PresentMon game FPS/frame-time measurements. Use PresentMon in parallel when establishing a game-performance baseline.

## Known limitations / next milestone

1. Add a selectable output and more robust adapter/output selection.
2. Add controlled capture-session recovery and window capture using Windows Graphics Capture.
3. Add internal counters and a reproducible benchmark harness.
4. Integrate NVENC only after the capture baseline is stable.
5. Add audio, muxing, bounded packet queues, and instant replay in later milestones.

## Safety and compatibility

The prototype uses documented Windows desktop-capture APIs. It does not inject into game processes or attempt to bypass anti-cheat systems. Protected content, exclusive display modes, hybrid-GPU routing, or driver limitations may prevent capture on some setups.
